// JavaScript for Facial Expression Recognition App

let videoStream = null;
let isProcessing = false;

// DOM Elements
const startBtn = document.getElementById('startWebcam');
const stopBtn = document.getElementById('stopWebcam');
const fileInput = document.getElementById('fileInput');
const video = document.getElementById('video');
const canvas = document.getElementById('canvas');
const cameraFeed = document.getElementById('cameraFeed');
const predictionCard = document.getElementById('predictionCard');
const emotionsList = document.getElementById('emotionsList');
const errorMessage = document.getElementById('errorMessage');

// Event Listeners
startBtn.addEventListener('click', startWebcam);
stopBtn.addEventListener('click', stopWebcam);
fileInput.addEventListener('change', handleFileUpload);

// Start webcam
async function startWebcam() {
    try {
        // Check if getUserMedia is supported
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            throw new Error('Camera access not supported in this browser');
        }

        // Check if we're on HTTPS or localhost
        const isSecure = location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1';
        if (!isSecure) {
            throw new Error('Camera access requires HTTPS or localhost');
        }

        // Request camera with mobile-friendly constraints
        const constraints = {
            video: {
                facingMode: 'user',
                width: { ideal: 640 },
                height: { ideal: 480 }
            }
        };

        const stream = await navigator.mediaDevices.getUserMedia(constraints);
        
        videoStream = stream;
        video.srcObject = stream;
        video.style.display = 'block';
        cameraFeed.style.display = 'none';
        
        startBtn.disabled = true;
        stopBtn.disabled = false;
        
        // Start periodic prediction
        setTimeout(() => predictFromVideo(), 1000);
        
        hideError();
    } catch (error) {
        console.error('Webcam error:', error);
        
        let errorMessage = 'Could not access camera. ';
        
        if (error.name === 'NotAllowedError') {
            errorMessage += 'Please allow camera permissions in your browser settings and try again.';
        } else if (error.name === 'NotFoundError') {
            errorMessage += 'No camera found on this device.';
        } else if (error.name === 'NotSupportedError') {
            errorMessage += 'Camera access not supported. Please use HTTPS or localhost.';
        } else if (error.message.includes('HTTPS')) {
            errorMessage += 'Camera access requires HTTPS. Please use a secure connection.';
        } else {
            errorMessage += 'Please check your camera permissions and try again.';
        }
        
        showError(errorMessage);
    }
}

// Stop webcam
function stopWebcam() {
    if (videoStream) {
        videoStream.getTracks().forEach(track => track.stop());
        videoStream = null;
    }
    
    video.style.display = 'none';
    cameraFeed.style.display = 'block';
    
    startBtn.disabled = false;
    stopBtn.disabled = true;
    
    hideResults();
}

// Handle file upload
async function handleFileUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = async (e) => {
        const imageData = e.target.result;
        await predictEmotion(imageData);
    };
    reader.readAsDataURL(file);
}

// Predict from video stream
async function predictFromVideo() {
    if (!videoStream || isProcessing) return;
    
    // Capture frame
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0);
    
    // Convert to base64
    const imageData = canvas.toDataURL('image/jpeg');
    
    // Predict
    await predictEmotion(imageData);
    
    // Schedule next prediction
    setTimeout(() => predictFromVideo(), 2000); // Every 2 seconds
}

// Predict emotion from image
async function predictEmotion(imageData) {
    if (isProcessing) return;
    
    isProcessing = true;
    hideError();
    
    try {
        const response = await fetch('/api/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ image: imageData })
        });
        
        const data = await response.json();
        
        if (data.error) {
            showError(data.error);
            hideResults();
        } else {
            displayResults(data);
        }
    } catch (error) {
        showError('Error predicting emotion. Please try again.');
        console.error('Prediction error:', error);
    } finally {
        isProcessing = false;
    }
}

// Display prediction results
function displayResults(data) {
    // Show demo notice if in demo mode
    const demoNotice = document.getElementById('demoNotice');
    if (data.demo_mode) {
        demoNotice.style.display = 'block';
    } else {
        demoNotice.style.display = 'none';
    }
    
    // Show main prediction card
    document.getElementById('emoji').textContent = data.emoji;
    document.getElementById('emotion').textContent = data.predicted_emotion;
    document.getElementById('confidence').textContent = 
        `Confidence: ${data.confidence_percentage.toFixed(1)}%`;
    
    predictionCard.style.display = 'block';
    
    // Show all emotions
    const emotionsBars = document.querySelector('.emotion-bars');
    emotionsBars.innerHTML = '';
    
    // Sort emotions by probability
    const sortedEmotions = Object.entries(data.all_emotions)
        .sort((a, b) => b[1].probability - a[1].probability);
    
    sortedEmotions.forEach(([emotion, info]) => {
        const bar = document.getElementById('emotion-bar-template').cloneNode(true);
        bar.style.display = 'block';
        bar.id = '';
        
        bar.querySelector('.emoji').textContent = info.emoji;
        bar.querySelector('.name').textContent = emotion;
        bar.querySelector('.bar-fill').style.width = `${info.percentage}%`;
        bar.querySelector('.percentage').textContent = `${info.percentage.toFixed(1)}%`;
        
        emotionsBars.appendChild(bar);
    });
    
    emotionsList.style.display = 'block';
}

// Show error message
function showError(message) {
    errorMessage.style.display = 'block';
    errorMessage.querySelector('p').textContent = message;
}

// Hide error message
function hideError() {
    errorMessage.style.display = 'none';
}

// Hide results
function hideResults() {
    predictionCard.style.display = 'none';
    emotionsList.style.display = 'none';
}

// Initialize
hideError();
hideResults();

