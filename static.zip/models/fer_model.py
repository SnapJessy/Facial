"""
Facial Expression Recognition Model using PyTorch
CNN Architecture for 7 emotion classes
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class FERModel(nn.Module):
    """
    Convolutional Neural Network for Facial Expression Recognition
    Input: 48x48 grayscale images
    Output: 7 emotion classes (Angry, Disgust, Fear, Happy, Sad, Surprise, Neutral)
    """
    
    def __init__(self, num_classes=7):
        super(FERModel, self).__init__()
        
        # Convolutional layers
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm2d(32)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm2d(64)
        self.conv3 = nn.Conv2d(64, 128, kernel_size=3, padding=1)
        self.bn3 = nn.BatchNorm2d(128)
        
        # Max pooling
        self.pool = nn.MaxPool2d(2, 2)
        
        # Dropout for regularization
        self.dropout = nn.Dropout(0.5)
        
        # Fully connected layers
        # After 3 max pools: 48 -> 24 -> 12 -> 6
        self.fc1 = nn.Linear(128 * 6 * 6, 256)
        self.fc2 = nn.Linear(256, 128)
        self.fc3 = nn.Linear(128, num_classes)
        
    def forward(self, x):
        # First conv block
        x = self.pool(F.relu(self.bn1(self.conv1(x))))
        
        # Second conv block
        x = self.pool(F.relu(self.bn2(self.conv2(x))))
        
        # Third conv block
        x = self.pool(F.relu(self.bn3(self.conv3(x))))
        
        # Flatten
        x = x.view(x.size(0), -1)
        
        # Fully connected layers
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        x = F.relu(self.fc2(x))
        x = self.dropout(x)
        x = self.fc3(x)
        
        return x


def get_model(num_classes=7):
    """Create and return the model instance"""
    model = FERModel(num_classes=num_classes)
    return model


def load_trained_model(model_path, device='cpu'):
    """
    Load a trained model from file
    
    Args:
        model_path: Path to the saved model file (.pth)
        device: Device to load model on ('cpu' or 'cuda')
    
    Returns:
        Loaded model
    """
    model = get_model()
    model.load_state_dict(torch.load(model_path, map_location=device))
    model.eval()
    return model


# Emotion labels mapping
EMOTION_LABELS = {
    0: 'Angry',
    1: 'Disgust',
    2: 'Fear',
    3: 'Happy',
    4: 'Sad',
    5: 'Surprise',
    6: 'Neutral'
}

EMOTION_EMOJIS = {
    'Angry': '😠',
    'Disgust': '🤢',
    'Fear': '😨',
    'Happy': '😊',
    'Sad': '😢',
    'Surprise': '😲',
    'Neutral': '😐'
}

